self.__precacheManifest = [
  {
    "revision": "b0fd1d32468e8d9a9e4f",
    "url": "/static/css/app.7fb30adb.css"
  },
  {
    "revision": "b0fd1d32468e8d9a9e4f",
    "url": "/static/js/app.10ab181b.js"
  },
  {
    "revision": "f562cc2f7cdfe28ab73d",
    "url": "/static/css/manifest.d7e25c9e.css"
  },
  {
    "revision": "f562cc2f7cdfe28ab73d",
    "url": "/static/js/manifest.9923a42a.js"
  },
  {
    "revision": "11c09127d5d7934ae7d4",
    "url": "/static/css/vendor.b57e4bfb.css"
  },
  {
    "revision": "11c09127d5d7934ae7d4",
    "url": "/static/js/vendor.db8295e7.js"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "14e11d0d1575baaec074cd41663b40cd",
    "url": "/static/img/logo.14e11d0d.png"
  },
  {
    "revision": "d16bd82d88647463698ad60714e0ab71",
    "url": "/static/img/background.d16bd82d.jpg"
  },
  {
    "revision": "98937e3a004f517209d9c6bc907e67ef",
    "url": "/static/img/headPortrait.98937e3a.jpg"
  },
  {
    "revision": "622869bf3f38b7945e0670b7e5b0f58e",
    "url": "/static/img/head.622869bf.png"
  },
  {
    "revision": "9a1959fd7f0d39bdc9c91ed2b05e4cff",
    "url": "/index.html"
  },
  {
    "revision": "922d1213e64f9ae5d16a85d5a0f28306",
    "url": "/config.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];